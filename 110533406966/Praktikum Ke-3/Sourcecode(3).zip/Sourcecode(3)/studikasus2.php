<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Studi Kasus 2 - Preselecting checkbox</title>
</head>

<body>
<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
Aliran musik: <br />
	<input type="checkbox" name="musik[]" value="Campursari" 
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Campursari') {
					echo "checked";
				}
		}
			
		} ?>
		>Campursari<br>
	<input type="checkbox" name="musik[]" value="Jazz"
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Jazz') {
					echo "checked";
				}
		}
			
		} ?>
		>Jazz<br>
	<input type="checkbox" name="musik[]" value="Bossanova"
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Bossanova') {
					echo "checked";
				}
		}
			
		} ?>
		>Bossanova<br>
	<input type="checkbox" name="musik[]" value="Pop"
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Pop') {
					echo "checked";
				}
		}
			
		} ?>
		>Pop<br>
	<input type="checkbox" name="musik[]" value="Rock"
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Rock') {
					echo "checked";
				}
		}
			
		} ?>
		>Rock<br>
	<input type="checkbox" name="musik[]" value="Blues"
	<?php if (isset($_POST['musik'])) {

			foreach ($_POST['musik'] as $key => $value) {
				if ($value=='Blues') {
					echo "checked";
				}
		}
			
		} ?>
		>Blues<br>
<input type="submit" value="OK" />
</form>

<?php
	if (isset($_POST['musik'])){
		foreach($_POST['musik'] as $key => $val){
		echo $key . ' -> ' . $val . '<br />';
		}
	}
?>
</body>
</html>