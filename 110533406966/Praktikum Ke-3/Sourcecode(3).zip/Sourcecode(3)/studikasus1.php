<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
 
<head> 
  <title>Preselecting penanganan seleksi</title> 
</head> 
 
<body> 
 
  <form action="<?php $_SERVER['PHP_SELF'];?>" method="post"> 
    Alamat
    <select name="alm"> 
      <option value="Tulungagung"
	<?php if (isset($_POST['alm'])&& $_POST['alm']=='Tulungagung'){
		echo "selected";
	}?>
	>Tulungagung</option>
      <option value="Blitar"
	<?php if (isset($_POST['alm'])&& $_POST['alm']=='Blitar'){
		echo "selected";
	}?>
	>Blitar</option>
      <option value="Malang"
	<?php if (isset($_POST['alm'])&& $_POST['alm']=='Malang'){
		echo "selected";
	}?>
	>Malang</option>
      <option value="Lumajang"
	<?php if (isset($_POST['alm'])&& $_POST['alm']=='Lumajang'){
		echo "selected";
	}?>
	>Lumajang</option>
    </select> <br /> 
 
    <input type="submit" value="ok" /> 
  </form> 
 
<?php 
if (isset($_POST['alm'])) { 
  echo $_POST['alm']; 
} 
?> 
 
</body> 
</html>