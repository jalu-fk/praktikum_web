<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Demo Variable</title>
</head>

<body>
	<?php
    	$bil=3;
		var_dump($bil);
		//Output : int(3)
		
		$var="";
		var_dump($var);
		//Output : string(0) ""
		
		$var = null;
		var_dump($var);
		//Output: NULL
	?>
</body>
</html>
