<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Tabel Otomatis</title>

</head>
<body>
<form method="post" action="tp2.2.php">
<h1 align="left"><font color = "blue" size = "6">Pembuatan Tabel Otomatis</font></h1>

<table width="327" border="1" bgcolor = "yellow">

<tr>
<td style="text-align:center"><label><font color = "red">Kolom</font></label></td>
<td><strong>= </strong>
<input name="JumlahColum" type="text" id="JumlahColum" onKeyUp="getmax();" onfocus="this.select();"></td>
</tr>
<tr>
<td style="text-align:center"><font color = "red">Sel Total</font></td>
<td><strong>= </strong>
<input name="JumlahCell" type="text" id="JumlahCell" onKeyUp="getmax();" onFocus="this.select();"></td>
</tr>

</table>

<br/>
<br/>
<br/>
<input type="submit" name="Generate" value="Generate..!!">
<input type="reset" name="Reset" value="Reset..!!">

</form>
</body>

</html>